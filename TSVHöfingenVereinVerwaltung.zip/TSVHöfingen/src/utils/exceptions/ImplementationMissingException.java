package utils.exceptions;

/**
 * Wird geworfen wenn implementation nicht vorhanden ist.
 * 
 * Z.B.: In leeren Funktion
 * public void Funktion() {
 * throw new ImplementationMissingException();
 * }
 */
public class ImplementationMissingException extends Exception {

    /**
     * @param message Exception Nachricht
     */
    public ImplementationMissingException(String message) {
        super(message);
    }

    public ImplementationMissingException() {
        super("Implementation missing!");
    }
}
