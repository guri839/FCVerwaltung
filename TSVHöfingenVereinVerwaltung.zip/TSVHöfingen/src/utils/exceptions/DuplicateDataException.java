package utils.exceptions;

/**
 * Wird geworfen, wenn es sich bei einem Datensatz um ein Duplikat handelt.
 */
public class DuplicateDataException extends Exception {

    /**
     * @param msg Exception Nachricht
     */
    public DuplicateDataException(String msg) {
        super(msg);
    }

}
