package utils.exceptions;

/**
 * Wird geworfen wenn eine Variable null oder leer ist.
 */
public class NullOrEmptyException extends Exception {

    /**
     * @param message Exception Nachricht
     */
    public NullOrEmptyException(String message) {
        super(message);
    }

    public NullOrEmptyException() {
        super("Is null or empty");
    }
}
