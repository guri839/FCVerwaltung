package utils;

/**
 * Wird implementiert von Klassen, von welcher Objekte als CSV exportiert werden
 * sollen.
 */
public interface CsvSerializeable {
    /**
     * Serialisiert Klasse zu CSV String.
     * 
     * @return CSV String
     */
    public String toCSV();
}
