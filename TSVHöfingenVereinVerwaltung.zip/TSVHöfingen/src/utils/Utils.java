package utils;

import java.util.Collection;
import java.util.Map;

public class Utils {

    Utils() {
        throw new InstantiationError(String.format("%s", getClass()));
    }

    /**
     * 
     * Util function to check if string is null or empty.
     * 
     * @param input String to validate
     * @return Returns true if string is valid else false.
     */
    public static boolean isNullOrEmpty(String input) {
        if (input == null || input.isEmpty()) {
            return true;
        }
        return false;
    }

    /**
     * 
     * Util function to check if collection is null or empty.
     * 
     * @param input {@link java.util.Collection} to validate
     * @return Returns true if {@link java.util.Collection} is valid else false.
     */
    public static boolean isNullOrEmpty(Collection<?> input) {
        if (input == null || input.isEmpty()) {
            return true;
        }
        return false;
    }

    /**
     * 
     * Util function to check if map is null or empty.
     * 
     * @param input {@link java.util.Map} to validate
     * @return Returns true if {@link java.util.Map} is valid else false.
     */
    public static boolean isNullOrEmpty(Map<?, ?> input) {
        if (input == null || input.isEmpty()) {
            return true;
        }
        return false;
    }

    /**
     * 
     * Util function to check if array is null or empty.
     * 
     * @param input Array to validate
     * @return Returns true if array is valid else false.
     */
    public static boolean isNullOrEmpty(Object[] input) {
        if (input == null || input.length <= 0) {
            return true;
        }
        return false;
    }

}
