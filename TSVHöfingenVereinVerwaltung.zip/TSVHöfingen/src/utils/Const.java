package utils;

/**
 * Klasse f�r statische Konstanten.
 */
public class Const {
    /**
     * CSV delimiter Zeichen.
     */
    public static final String CSV_DELIMITER = ",";

    /**
     * CSV-Dateiendung
     */
    public static final String CSV_FILE_EXTENSION = ".csv";

    /**
     * Standardpfad f�r das Speichern und Laden von Mitgliedern
     * Standardwert: 'mitglieder.csv'.
     */
    public static final String FILE_DEFAULT_PATH = String.format("%s%s", "mitglieder", CSV_FILE_EXTENSION);
}
