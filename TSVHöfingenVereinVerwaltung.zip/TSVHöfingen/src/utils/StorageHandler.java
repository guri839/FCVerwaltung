package utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;

import utils.exceptions.NullOrEmptyException;

/**
 * Hilfsklasse zum schreiben oder laden einer CSV Datei.
 */
public class StorageHandler {

    /**
     * 
     * Schreibt eine Liste von CSV-Serialisierbaren Objekten in eine CSV Datei,
     * welche durch 'filePath' angegeben wird.
     * 
     * @param dataToWrite List von CSV-Serialisierbaren Objekten
     * @param filePath    Pfad zu Datei in welche gespeichert wird.
     * @throws NullOrEmptyException Wenn versucht wird leere Liste zu schreiben.
     */
    public void writeToFile(ArrayList<? extends CsvSerializeable> dataToWrite, Path filePath)
            throws NullOrEmptyException {

        // Verhindert das Speichern einer leeren Datei
        if (Utils.isNullOrEmpty(dataToWrite)) {
            throw new NullOrEmptyException();
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(new File(filePath.toRealPath().toString())))) {

            for (CsvSerializeable s : dataToWrite) {
                writer.write(String.format("%s%n", s.toCSV()));
            }

        } catch (IOException e) {
            System.out.printf("IO exception while writing: %s%n", e.toString());
        }
    }

    /**
     * 
     * Liest die einzelnen einer angegebenen Datei ein.
     * 
     * @param filePath Pfad zur Datei, welche geladen werden soll
     * @return Liste der eingelesenen Zeilen
     * @throws IOException Wenn Datei nicht geladen werden konnte.
     */
    public ArrayList<String> loadFromFile(Path filePath) throws IOException {

        ArrayList<String> out = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(new File(filePath.toRealPath().toString())))) {

            String line = null;
            while ((line = reader.readLine()) != null) {
                // // Leere Zeilen ueberspringen.
                // if (line.length() > 0) {
                out.add(line);
                // }
            }

            return out;

        } catch (IOException e) {
            throw e;
        }
    }

}
