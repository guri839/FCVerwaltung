package cli;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

import membermanagement.managements.MemberManagement;
import membermanagement.managements.PlayerManagement;
import membermanagement.managements.TrainerManagement;
import membermanagement.members.Member;
import membermanagement.members.Player;
import membermanagement.members.Trainer;
import membermanagement.utils.MemberParser;
import utils.Const;
import utils.StorageHandler;
import utils.Utils;
import utils.exceptions.DuplicateDataException;
import utils.exceptions.ImplementationMissingException;
import utils.exceptions.NullOrEmptyException;

/**
 * Konsolenanwendung zum verwenden der Mitgliederverwaltung
 * 
 * <pre>
 * <code>
 * 
 * MemberManagement mm = new MemberManagement();
 * CLI.memberManagement = mm;
 * CLI.mainMenu();
 * 
 * </code>
 * </pre>
 */
public class CLI {

	/**
	 * Scanner-Instanz zum lesen von Benutzereingaben
	 */
	private static Scanner scanner = new Scanner(System.in);
	/**
	 * StorageHandler-Instanz zum speichern und laden von Dateien
	 */
	private static StorageHandler storageHandler = new StorageHandler();
	/**
	 * MitgliederVerwaltungs-Instanz. Muss von der aufrufenden Klasse an die CLI
	 * übergeben werden!
	 */
	public static MemberManagement memberManagement = new MemberManagement();

	// #region Hilfsfunktionen

	/**
	 * 
	 * Versucht Zahl aus Benutzereingabe einzulesen. Behandelt fehleingaben
	 * rudimentaer.
	 * 
	 * @see CLI#readInt(null)
	 * 
	 * @return Integer eingelesene Zahl
	 */
	private static Integer readInt() {
		return readInt(null);
	}

	/**
	 * Versucht Zahl aus Benutzereingabe einzulesen. Behandelt fehleingaben
	 * rudimentaer. Akzeptiert Standardwert, welcher verwendet wird, wenn der
	 * Benutzer eine leere Eingabe taetigt.
	 * 
	 * @return Integer eingelesene Zahl
	 */
	private static Integer readInt(Integer defaultValue) {
		// Beinhaltet Benutzereingabe.
		String input = "";
		// Ergebnis, welches zurueck gegeben wird.
		Integer readNumber = null;
		while (readNumber == null) {
			System.out.printf(":");
			try {
				// Eingabe lesen
				input = scanner.nextLine();

				// Wenn ein Standardwert gegeben ist, und der Benutzer keine Eingabe getaetigt
				// hat,
				// soll der Standardwert verwendet werden.
				if (defaultValue != null && input.length() == 0) {
					readNumber = defaultValue;
				} else {
					// Wenn der Nutzer eine eingabe taetigt
					readNumber = Integer.valueOf(input);
				}

			} catch (NumberFormatException e) {
				invalidInput(input);
			}
		}
		return readNumber;
	}

	/**
	 * Hilfsfunktion zum einlesen eines Strings, welcher nicht leer sein darf.
	 * 
	 * @see CLI#readString(boolean)
	 * 
	 * @return String Benutzereingabe
	 */
	private static String readString() {
		return readString(null);
	}

	/**
	 * 
	 * Hilfsfunktion zum einlesen eines Strings von Benutzereingabe Akzeptiert
	 * Standardwert, welcher verwendet wird, wenn der Benutzer eine leere Eingabe
	 * taetigt
	 * 
	 * @param defaultValue String Standardwert
	 * @return String Benutzereingabe
	 */
	private static String readString(String defaultValue) {
		String readString = null;
		while (readString == null) {
			System.out.printf(":");

			String input = scanner.nextLine();

			if (defaultValue == null && input.length() == 0) {
				System.out.println("Eingabe darf nicht leer sein!");
			} else if ((!Utils.isNullOrEmpty(defaultValue)) && input.length() == 0) {
				readString = defaultValue;
			} else {
				readString = input;
			}
		}
		return readString;
	}

	/**
	 * Hilfsfunktion um ungueltige eingaben darzustellen.
	 * 
	 * @param arg Ungueltige eingabe
	 */
	private static void invalidInput(Object arg) {
		System.err.printf("Ungueltige Eingabe '%s'%n%n", arg.toString());
	}

	/**
	 * Einfacher y/n Bestaetigungsdialog
	 * 
	 * @param text      Frage welche mit y oder n beantwortet wird
	 * @param defaultNo boolean welcher entscheidet ob unguelitge Eingaben zu einem
	 *                  y oder einem n fuehren
	 * @return
	 */
	private static boolean confirmDialog(String text, boolean defaultNo) {

		if (defaultNo) {
			// Bestaetigungsfrage stellen
			System.out.printf("%s (y/N)", text);
			String input = readString("n");
			// Entscheidung darstellen
			System.out.println(input);
			System.out.println();
			return input.equalsIgnoreCase("y");

		} else {
			// Bestaetigungsfrage stellen
			System.out.printf("%s (Y/n)", text);
			String input = readString("y");
			// Entscheidung darstellen
			System.out.println(input);
			System.out.println();
			return !input.equalsIgnoreCase("n");
		}

	}

	// #endregion

	/**
	 * Das Hauptmenue ist der Allgemeine Einstiegspunkt der CLI-Anwendung
	 *
	 */
	public static void mainMenu() {

		Integer input = -1;

		while (input != 0) {

			System.out.println("Hauptmenue:");
			System.out.println("0. Programm beenden");
			System.out.println("1. Mitglieder auflisten");
			System.out.println("2. Mitglied hinzufuegen/entfernen");
			System.out.println("3. Mitglied importieren/exportieren");

			input = readInt();
			System.out.println();

			switch (input) {
			// Beenden der Anwendung
			case 0:
				System.exit(0);
				return;
			// Untermenue zum auflisten verschiedener Mitglieder
			case 1:
				listMembersMenu();
				break;
			// Untermenue zum erstelle, bearbeiten und loeschen von Mitgliedern
			case 2:
				editMemberMenu();
				break;
			// Untermenue zum importieren und exportieren von Mitgliedern
			case 3:
				importExportMembersMenu();
				break;
			default:
				invalidInput(input);
				break;
			}
		}
	}

	/**
	 * Menue zum importieren und exportieren von Mitgliedern
	 */
	private static void importExportMembersMenu() {

		System.out.println("Mitglieder Importieren/Exportieren:");
		System.out.println("1. Importieren");
		System.out.println("2. Exportieren");
		System.out.println("0. Zurueck");

		int input = readInt();
		System.out.println();

		switch (input) {
		// Zurueck ins Elternmenue
		case 0:
			return;
		// Mitglieder import von Datei wizard
		case 1:
			importMembersFromFileWizard();
			return;
		case 2:
			exportMembersToFileWizard(); // Men�punkt exportiere Datei
			return;
		default:
			invalidInput(input); // Exception ung�ltige Eingabe
			return;
		}
	}

	/**
	 * Wizard zum importieren von Mitgliedern von einer Datei
	 * 
	 * Wizard fuehrt Benutzer durch den Prozess des Datei imports. Behandelt
	 * aufkommende Fehler.
	 * 
	 */
	private static void importMembersFromFileWizard() {

		System.out.println("Mitglieder Importieren:");
		System.out.println("0. Zurueck");
		System.out.printf("Pfad fuer CSV Datei eingeben [%s]%n", Const.FILE_DEFAULT_PATH);

		String input = readString(Const.FILE_DEFAULT_PATH);
		System.out.println();

		// Zurueck ins Elternmnue
		if (input.compareTo("0") == 0) {
			return;
		}

		Path filePath = Paths.get(input);

		// Ueberpruefen ob angegebene Datei existiert
		if (filePath.toFile().exists()) {

			try {
				System.out.printf("Importiere Mitglieder von '%s'...%n%n", filePath.toString());

				// Angegebene Datei laden und parsen
				MemberParser mp = new MemberParser();
				ArrayList<String> readLines = storageHandler.loadFromFile(filePath);
				ArrayList<Member> parsed = mp.parse(readLines);
				int importCounter = 0;
				for (Member m : parsed) {
					try {
						// Zuweisung der importierten Daten in die Liste
						memberManagement.add(m);
						importCounter++;
					} catch (DuplicateDataException e) {
						System.err.printf("Mitgliedsnummer '%d' existiert bereits. Ueberspringe import.%n",
								m.getMemberNumber());
					} catch (Exception e) {
						System.err.printf("Fehler beim importieren: %s %n", e.getMessage());
					}
				}
				System.out.printf("%nEs wurden %d/%d Mitglieder aus %d Zeilen von '%s' erfolgreich importiert! %n%n",
						importCounter, parsed.size(), readLines.size(), input);
			} catch (Exception e) {
				// TODO: sollte was getan werden
				System.err.printf("%s%n", e.getMessage());
				e.printStackTrace();
				System.out.println();
			}

		} else {
			System.err.printf("%nDie angegebene Datei '%s' konnte nicht gefunden werden.%n%n", filePath.toString());
		}

		return;
	}

	/**
	 * Wizard zum exportieren von Mitgliedern in eine Datei
	 * 
	 * Wizard fuehrt Benutzer durch den Prozess des Datei exports. Behandelt
	 * aufkommende Fehler.
	 * 
	 */
	private static void exportMembersToFileWizard() {
		System.out.println("Mitglieder Exportieren:");
		System.out.println("0. Zurueck");
		System.out.printf("Pfad fuer CSV Datei eingeben [%s]%n", Const.FILE_DEFAULT_PATH);

		String input = readString(Const.FILE_DEFAULT_PATH);
		System.out.println();

		// Zurueck ins Elternmnue
		if (input.compareTo("0") == 0) {
			return;
		}

		// Ueberpruefen ob .csv eingegeben wurde. Wenn nicht, anfuegen
		if (!(input.indexOf(Const.CSV_FILE_EXTENSION) > 0)) {
			input = String.format("%s%s", input, Const.CSV_FILE_EXTENSION);
		}

		Path filePath = Paths.get(input);

		// Ueberpruefen ob datei bereits existiert
		if (filePath.toFile().exists()) {
			if (confirmDialog(String.format("Pfad '%s' existiert bereits. Ueberschreiben?", filePath), true)) {

				System.out.printf("Exportiere Mitglieder nach '%s'...%n%n", filePath.toString());

				try {
					storageHandler.writeToFile(memberManagement.getMembers(), filePath);
					System.out.printf("Es wurden %d Mitglieder nach '%s' erfolgreich exportiert %n%n",
							memberManagement.getMembers().size(), input);
				} catch (NullOrEmptyException e) {
					System.err.printf("Es existieren keine Mitglieder zum exportieren! %n%n");
				} catch (Exception e) {
					System.err.printf("Failed to write: %s %n", e.getMessage());
					e.printStackTrace();
					System.out.println();
				}
			} else {
				System.out.println("Exportieren abgebrochen!");
			}
		}
		return;
	}

	/**
	 * Menue zum auflisten von Mitgliedern
	 * 
	 * Erlaubt das Auflisten von allen Mitglieder, sowie nur den Trainern oder den
	 * Spielern
	 */
	private static void listMembersMenu() {
		System.out.println("Mitglieder auflisten:");
		System.out.println("0. Zurueck");
		System.out.println("1. Alle");
		System.out.println("2. Trainer");
		System.out.println("3. Spieler");

		int input = readInt();
		System.out.println();

		switch (input) {
		case 0:
			return;
		// Alle member ausgeben
		case 1:
			if (CLI.sortMembersDialog()) {
				CLI.sortMembersByPropertyMenu(memberManagement);
			}
			memberManagement.print();
			break;
		// Alle Trainer ausgeben
		case 2:
			TrainerManagement tv = memberManagement.getTrainerManagement();
			if (CLI.sortMembersDialog()) {
				CLI.sortTrainersByPropertyMenu(tv);
			}
			tv.print();
			break;
		// Alle Spieler ausgeben
		case 3:
			PlayerManagement sv = memberManagement.getPlayerManagement();

			if (CLI.sortMembersDialog()) {
				CLI.sortPlayersByPropertyMenu(sv);
			}
			sv.print();
			break;
		default:
			invalidInput(input);
		}

		System.out.println();

	}

	private static boolean sortMembersDialog() {
		return CLI.confirmDialog("Mitglieder sortieren?", true);
	}

	/**
	 * Dialog fuer aufsteigend-/absteigende Sortierung.
	 * 
	 * @return boolean true, wenn aufsteigend, false bei absteigend.
	 */
	private static boolean sortMembersAscendingDialog() {
		return CLI.confirmDialog("Mitglieder aufsteigend sortieren?", false);
	}

	/**
	 * Menue zum sortieren einer Trainerverwaltung anhand der Eigenschaften eines
	 * Trainers.
	 * 
	 * @param tm Trainerverwaltung, welche sortiert werden soll.
	 */
	private static void sortTrainersByPropertyMenu(TrainerManagement tm) {
		System.out.println("Trainer sortieren:");
		System.out.println("0. Zurueck");
		System.out.println("1. Vorname");
		System.out.println("2. Nachname");
		System.out.println("3. Mitgliedsnummer");
		System.out.println("4. Mannschaft");

		int sorting = readInt();
		System.out.println();

		// Abfrage ob aufsteigend oder absteigend sortiert werden soll.
		boolean asc = CLI.sortMembersAscendingDialog();

		switch (sorting) {
		case 0:
			return;
		// Nach Vorname sortieren.
		case 1:
			tm.sortByName(asc);
			break;
		// Nach Nachname sortieren.
		case 2:
			tm.sortBySurName(asc);
			break;
		// Nach Mitgliedsnummer sortieren.
		case 3:
			tm.sortByMemberNumber(asc);
			break;
		// Nach Mannschaft sortieren.
		case 4:
			tm.sortByTeam(asc);
			break;
		default:
			invalidInput(sorting);
			break;
		}
	}

	/**
	 * Menue zum sortieren einer Spielerverwaltung anhand der Eigenschaften eines
	 * Spielers.
	 * 
	 * @param pm Spielerverwaltung, welche sortiert werden soll.
	 */
	private static void sortPlayersByPropertyMenu(PlayerManagement pm) {
		System.out.println("Spieler sortieren:");
		System.out.println("0. Zurueck");
		System.out.println("1. Vorname");
		System.out.println("2. Nachname");
		System.out.println("3. Mitgliedsnummer");
		System.out.println("4. Mannschaft");
		System.out.println("5. Tore");
		System.out.println("6. Position");

		int sorting = readInt();
		System.out.println();

		// Abfrage ob aufsteigend oder absteigend sortiert werden soll.
		boolean asc = CLI.sortMembersAscendingDialog();

		switch (sorting) {
		case 0:
			return;
		// Nach Vorname sortieren.
		case 1:
			pm.sortByName(asc);
			break;
		// Nach Nachname sortieren.
		case 2:
			pm.sortBySurName(asc);
			break;
		// Nach Mitgliedsnummer sortieren.
		case 3:
			pm.sortByMemberNumber(asc);
			break;
		// Nach Mannschaft sortieren.
		case 4:
			pm.sortByTeams(asc);
			break;
		// Nach Toren sortieren.
		case 5:
			pm.sortByGoals(asc);
			break;
		// Nach Position sortieren
		case 6:
			pm.sortByPosition(asc);
			break;
		default:
			invalidInput(sorting);
			break;
		}
	}

	/**
	 * Menue zum sortieren einer Mitgliederverwaltung anhand der Eigenschaften eines
	 * Mitglieds.
	 * 
	 * @param mm Mitgliederverwaltung, welche sortiert werden soll.
	 */
	private static void sortMembersByPropertyMenu(MemberManagement mm) {
		System.out.println("Mitglieder sortieren:");
		System.out.println("0. Zurueck");
		System.out.println("1. Vorname");
		System.out.println("2. Nachname");
		System.out.println("3. Mitgliedsnummer");
		System.out.println("4. Mitgliedstyp");

		int sorting = readInt();
		System.out.println();

		// Abfrage ob aufsteigend oder absteigend sortiert werden soll.
		boolean asc = CLI.sortMembersAscendingDialog(); // Zuweisung true/false wert

		switch (sorting) {
		case 0:
			return;
		// Sortieren nach Vorname
		case 1:
			mm.sortByName(asc);
			break;
		// Sortieren nach Nachname
		case 2:
			mm.sortBySurName(asc);
			break;
		// Sortieren nach Mitgliedsnummer
		case 3:
			mm.sortByMemberNumber(asc);
			break;
		// Sortieren nach Mitgliedstyp
		case 4:
			mm.sortByType(asc);
			break;
		default:
			invalidInput(sorting);
			break;
		}
	}

	/**
	 * Untermenue zum hinzufuegen, bearbeiten und entfernen eines Mitglieds
	 * 
	 * @throws ImplementationMissingException
	 */
	private static void editMemberMenu() {
		System.out.println("Mitglieder hinzufuegen / entfernen");
		System.out.println("0. Zurueck");
		System.out.println("1. Spieler hinzufuegen");
		System.out.println("2. Trainer hinzufuegen");
		System.out.println("3. Mitglied entfernen");

		int input = readInt();
		System.out.println();

		switch (input) {
		case 0:
			return;
		// Spieler hinzufuegen
		case 1:
			addPlayerWizard();
			break;
		// Trainer hinzufuegen
		case 2:
			addTrainerWizard();
			break;
		// Mitglied entfernen
		case 3:
			removeMemberWizard();
			break;
		default:
			invalidInput(input);
			break;
		}
	}

	/**
	 * Wizard fuers hinzufuegen eines Spielers zur Mitgliederverwaltung
	 */
	private static void addPlayerWizard() {
		System.out.printf("Mitgliedsnummer");
		int memberNumber = readInt();
		System.out.printf("Vorname");
		String name = readString();
		System.out.printf("Nachname");
		String surName = readString();
		System.out.printf("Tore");
		int goals = readInt();
		System.out.printf("Mannschaft");
		String team = readString();
		System.out.printf("Position");
		String position = readString();
		System.out.println();

		try {
			Player p = new Player(memberNumber, name, surName, goals, team, position);

			if (confirmDialog(String.format("Soll '%s' erstellt werden?", p), false)) {
				memberManagement.createPlayer(memberNumber, name, surName, goals, team, position);
			} else {
				System.out.printf("'%s' wurde nicht erstellt.%n", p);
			}
		} catch (DuplicateDataException e) {
			System.out.printf("Ein Mitglied mit der Nummer %d existiert bereits!%n", memberNumber);
			System.out.println("Mitglied wurde nicht hinzugefuegt.");
		}
	}

	/**
	 * Wizard fuers hinzufuegen eines Trainers zur Mitgliederverwaltung Erlaubt das
	 * bearbeiten der eingegebenen Werte bei ungueltiger Eingabe
	 */
	private static void addTrainerWizard() {
		System.out.printf("Mitgliedsnummer");
		int memberNumber = readInt();
		System.out.printf("Vorname");
		String name = readString();
		System.out.printf("Nachname");
		String surName = readString();
		System.out.printf("Mannschaft");
		String team = readString();
		System.out.println();

		try {
			Trainer t = new Trainer(memberNumber, name, surName, team);

			if (confirmDialog(String.format("Soll '%s' erstellt werden?", t), false)) {
				memberManagement.createTrainer(memberNumber, name, surName, team);
			} else {
				System.out.printf("'%s' wurde nicht erstellt.%n", t);
			}
		} catch (DuplicateDataException e) {
			System.out.printf("Ein Mitglied mit der Nummer %d existiert bereits!%n", memberNumber);
			System.out.println("Mitglied wurde nicht hinzugefuegt.");
		}
	}

	/**
	 * Wizard zum entfernen einens Mitglieds
	 */
	private static void removeMemberWizard() {
		System.out.println("Geben Sie die Mitgliedsnummer ein");
		int memberNumber = readInt();
		System.out.println();

		try {
			Member m = memberManagement.getMember(memberNumber);

			if (confirmDialog(String.format("Soll '%s' geloescht werden?", m), true)) {
				memberManagement.deleteMember(m);
			} else {
				System.out.printf("'%s' wurde nicht geloescht.%n", m);
			}

		} catch (Exception e) {

		}
	}

}
