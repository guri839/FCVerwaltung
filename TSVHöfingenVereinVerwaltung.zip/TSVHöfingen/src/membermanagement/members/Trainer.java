package membermanagement.members;

import utils.Const;

/**
 * Representiert einen Trainer als Mitglied
 */
public class Trainer extends Member {

	/**
	 * Mannschaft
	 */
	private String team;
	/**
	 * Mitgliedstyp
	 */
	public static final String TYPE = "Trainer";

	/**
	 * 
	 * @param memberNumber Mitgliedsnummer
	 * @param name         Vorname
	 * @param surname      Nachname
	 * @param team         Mannschaft
	 */
	public Trainer(int memberNumber, String name, String surname, String team) {
		super(TYPE, memberNumber, name, surname);
		this.setTeam(team);
	}

	/**
	 * @return Mannschaft
	 */
	public String getTeam() {
		return team;
	}

	/**
	 * @param team Mannschaft
	 */
	public void setTeam(String team) {
		this.team = team;
	}

	@Override
	public String toString() {
		return String.format("%s Mannschaft: %10s ", super.toString(), team);
	}

	/**
	 * Seriealisiert Klasse in CSV formatierten String
	 */
	public String toCSV() {
		return String.join(Const.CSV_DELIMITER, super.toCSV(), getTeam());
	}

}
