package membermanagement.members;

import utils.Const;

/**
 * Representiert einen Spieler als Mitglied
 */
public class Player extends Member {

	/**
	 * Tore
	 */
	private int goals;
	/**
	 * Mannschaft
	 */
	private String team;
	/**
	 * Position
	 */
	private String position;

	/**
	 * Mitgliedstyp
	 */
	public static final String TYPE = "Spieler";

	/**
	 * 
	 * @param memberNumber Mitgliedsnummer
	 * @param name         Vorname
	 * @param surName      Nachname
	 * @param goals        Tore
	 * @param team         Mannschaft
	 * @param position     Position
	 */
	public Player(int memberNumber, String name, String surName, int goals, String team, String position) {
		super(TYPE, memberNumber, name, surName);
		this.setGoals(goals);
		this.setTeam(team);
		this.setPosition(position);
	}

	/**
	 * @return Tore
	 */
	public Integer getGoals() {
		return Integer.valueOf(goals);
	}

	/**
	 * @param goals Tore
	 */
	public void setGoals(int goals) {
		this.goals = goals;
	}

	/**
	 * @return Mannschaft
	 */
	public String getTeam() {
		return team;
	}

	/**
	 * @param team Mannschaft
	 */
	public void setTeam(String team) {
		this.team = team;
	}

	/**
	 * @return Position
	 */
	public String getPosition() {
		return position;
	}

	/**
	 * @param position Position
	 */
	public void setPosition(String position) {
		this.position = position;
	}

	@Override
	public String toString() {
		return String.format("%s Mannschaft: %10s Tore: %3d  Position: %10s", super.toString(), getTeam(), getGoals(),
				getPosition());
	}

	/**
	 * Seriealisiert Klasse in CSV formatierten String
	 */
	public String toCSV() {
		return String.join(Const.CSV_DELIMITER, super.toCSV(), getTeam(), getPosition(), getGoals().toString());
	}

}
