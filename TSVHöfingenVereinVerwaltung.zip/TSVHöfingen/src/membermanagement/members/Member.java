package membermanagement.members;

import utils.Const;
import utils.CsvSerializeable;

/**
 * Elternklasse fuer Mitglieder welche von Mitgliederverwaltungsklasse verwaltet
 * werden.
 */
public abstract class Member implements CsvSerializeable {

	/**
	 * Beschreibt den Typ des Mitglieds.
	 */
	private String type;
	/**
	 * Eindeutige id um Mitglieder identifizieren zu koennen.
	 */
	private int memberNumber;
	/**
	 * Vorname des Mitglieds
	 */
	private String name;
	/**
	 * Nachname des Mitglieds
	 */
	private String surName;

	/**
	 * Constructor
	 * 
	 * @param type         Mitgliedstyp
	 * @param memberNumber Mitgliedsnummer
	 * @param name         Vorname
	 * @param surName      Nachname
	 */
	public Member(String type, int memberNumber, String name, String surName) {
		super();
		this.setType(type);
		this.setMemberNumber(memberNumber);
		this.setName(name);
		this.setSurName(surName);
	}

	/**
	 * @return Mitgliedstyp
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type Mitgliedstyp
	 */
	private void setType(String type) {
		this.type = type;
	}

	/**
	 * @param memberNumber Mitgliedsnummer
	 */
	private void setMemberNumber(int memberNumber) {
		this.memberNumber = memberNumber;
	}

	/**
	 * @return Mitgliedsnummer
	 */
	public Integer getMemberNumber() {
		return Integer.valueOf(memberNumber);
	}

	/**
	 * @return Vorname
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name Vorname
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return Nachname
	 */
	public String getSurName() {
		return surName;
	}

	/**
	 * @param surName Nachname
	 */
	public void setSurName(String surName) {
		this.surName = surName;
	}

	@Override
	public String toString() {
		return String.format("%7s: Mitgliedsnummer: %3d Vorname: %10s Nachname: %10s", getType(), getMemberNumber(),
				getName(), getSurName());
	}

	/**
	 * Seriealisiert Klasse in CSV formatierten String
	 */
	public String toCSV() {
		return String.join(Const.CSV_DELIMITER, getType(), getMemberNumber().toString(), getName(), getSurName());
	}

}
