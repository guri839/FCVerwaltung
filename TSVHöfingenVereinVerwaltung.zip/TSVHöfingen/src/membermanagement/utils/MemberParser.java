package membermanagement.utils;

import java.util.ArrayList;

import membermanagement.members.Member;
import membermanagement.members.Player;
import membermanagement.members.Trainer;
import utils.Const;
import utils.Utils;
import utils.exceptions.ImplementationMissingException;
import utils.exceptions.NullOrEmptyException;

/**
 * Wandelt CSV serialisierte Mitglieder in jeweilige Objekte um.
 */
public class MemberParser {

    /**
     * Wandelt Liste von CSV-Werten in Liste von Mitgliedern um.
     * 
     * @param csvLines ArrayList von Strings, welche einzenle CSV Textzeilen
     *                 beinhaltet
     * @return Liste von deserialisierten Mitgliedern
     * @throws NullOrEmptyException Wenn eine leere Liste uebergeben wurde.
     */
    public ArrayList<Member> parse(ArrayList<String> csvLines) throws NullOrEmptyException {

        // Ergebnis Liste von umgewandelten Mitgliedern
        ArrayList<Member> out = new ArrayList<Member>();

        // Schutz vor leerer ArrayList
        if (Utils.isNullOrEmpty(csvLines)) {
            throw new NullOrEmptyException();
        }

        for (int i = 0; i < csvLines.size(); i++) {

            String csvLine = csvLines.get(i);
            int textLineIndex = i + 1;

            if (!Utils.isNullOrEmpty(csvLine)) {

                // Entfernen aller white-space symbole eg. space, tab und linefeed
                csvLine = csvLine.replaceAll("\\s", "");

                String[] csvValues = csvLine.split(Const.CSV_DELIMITER);

                String memberType = csvValues[0];

                try {
                    /**
                     * Identifiezieren des Mitgliedstyps
                     * 'values' Index 0 = Mitgliedstyp
                     */
                    if (memberType.equals(Trainer.TYPE)) {
                        out.add(this.parseTrainer(csvValues));
                    } else if (memberType.equals(Player.TYPE)) {
                        out.add(this.parseSpieler(csvValues));
                    } else {
                        throw new ImplementationMissingException();
                    }
                } catch (ImplementationMissingException e) {
                    System.err.printf("Unbekannter Mitgliedstyp: '%s' (Zeile: %d)%n", memberType, textLineIndex);
                } catch (Exception e) {
                    // Beinhaltet den grund fuer Exception
                    String reason = "";

                    // Grund fuer die Exception ausfindig machen
                    if (e instanceof ArrayIndexOutOfBoundsException) {
                        reason = "Unvollstaendiger Datensatz!";
                    } else if (e instanceof NumberFormatException) {
                        // Parser fehler ausgeben und auf den fehlerhaften Wert kuerzen
                        // Z.B.: 'For input string: "Elf"' -> 'Elf'
                        reason = String.format("Ungueltiger Datensatz: '%s' (Zahl ertwartet!)",
                                e.getMessage().split("\"")[1]);
                    } else {
                        // Unbekannte fehler werden allgemein ausgegeben
                        reason = String.format("Unbekannter Fehler! (%s)", e.getMessage());
                    }

                    System.err.printf("Fehler beim einlesen: '%s' (Zeile: %d) [%s]%n", csvLine, textLineIndex, reason);
                }
            }

        }

        return out;
    }

    /**
     * Akzptiert Trainer CSV werte als Array und versucht Trainer Objekt daraus zu
     * erstellen.
     * 
     * @param csvValues String Array
     * @return Trainer Instanz
     * @throws Exception Wenn ein Wert nich korrekt geparsed werden konnte.
     */
    private Trainer parseTrainer(String[] csvValues) throws Exception {

        Trainer trainer = null;

        try {
            int memberNumber = Integer.valueOf(csvValues[1]);
            String name = csvValues[2];
            String surName = csvValues[3];
            String team = csvValues[4];

            trainer = new Trainer(memberNumber, name, surName, team);
        } catch (Exception e) {
            throw e;
        }

        return trainer;
    }

    /**
     * Akzptiert Spieler CSV werte als Array und versucht Spieler Objekt daraus zu
     * erstellen.
     * 
     * @param csvValues String Array
     * @return Player Instanz
     * @throws Exception Wenn ein Wert nich korrekt geparsed werden konnte.
     */
    private Player parseSpieler(String[] csvValues) throws Exception {

        Player spieler = null;

        try {
            int memberNumber = Integer.valueOf(csvValues[1]);
            String name = csvValues[2];
            String surName = csvValues[3];
            int goals = Integer.valueOf(csvValues[6]);
            String team = csvValues[4];
            String position = csvValues[5];

            spieler = new Player(memberNumber, name, surName, goals, team, position);
        } catch (Exception e) {
            throw e;
        }

        return spieler;
    }

}
