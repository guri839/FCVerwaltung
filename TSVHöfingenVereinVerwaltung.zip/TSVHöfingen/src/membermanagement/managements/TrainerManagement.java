package membermanagement.managements;

import java.util.ArrayList;
import java.util.Comparator;

import membermanagement.members.Member;
import membermanagement.members.Trainer;

/**
 * Mitgliederverwaltungsklasse, welche nur Mitglieder des Typs Trainer beinhaltet.
 * Diese Klasse bietet nur Lesende Aktionen auf die Mitglieder liste.
 * Sie dient als gefilterte Version der Hauptverwaltung (Mitgliederverwaltung).
 * Wird verwedent um z.B: nur alle Trainer auf zu listen.
 * 
 * Sortierfunktionen für Eigenschaften, welche nur Trainer besitzen, sollen
 * hier ebenfalls implementiert werden.
 */
public class TrainerManagement extends BaseManagement {
	
    /**
     * Diese Klasse wird von {@link MemberManagement#getTrainerManagement()} ausgestellt und sollte
     * auch nur von dieser  instaziert werden.
     * @param trainers Mitgliederliste welche nur Trainer beinhaltet
     */
	TrainerManagement(ArrayList<Member> trainers) {
		super();
		this.setMembers(trainers);
	}

    /**
     * Soll ueber diesen Weg nicht instanziert werden!
     */
    TrainerManagement() {
        throw new InstantiationError(String.format("%s", getClass()));
    }

    /**
     * Sortiert alle Trainer aus Mitgliederliste nach Team
     * @param asc Aufsteigend sortieren
     */
	public void sortByTeam(boolean asc) {
        this.getMembers().sort(new Comparator<Member>() {

            @Override
            public int compare(Member o1, Member o2) {
				Trainer t1 = (Trainer) o1;
				Trainer t2 = (Trainer) o2;

                if (asc) {      // Falls Wert wahr aufsteigend sort.S
                    return t1.getTeam().compareTo(t2.getTeam());
                } else {
                    return t2.getTeam().compareTo(t1.getTeam());
                }

            }
        });
    }

}
