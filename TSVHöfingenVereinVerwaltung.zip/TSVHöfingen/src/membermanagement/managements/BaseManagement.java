package membermanagement.managements;

import java.util.ArrayList;
import java.util.Comparator;

import membermanagement.exceptions.MemberNotFoundException;
import membermanagement.members.Member;
import utils.Utils;

/**
 * Basisklasse fuer Mitgliederverwaltungsklassen
 */
public abstract class BaseManagement {

	/**
     * Liste der Mitglieder, welche durch Verwaltungsklassen verwaltet wird.
     */
    private ArrayList<Member> members = new ArrayList<>();

    /**
     * Getter Mitgliederliste
     * @return Mitgliederliste
     */
    public ArrayList<Member> getMembers() {
        return members;
    }

    /**
     * Setter Mitgliederliste
     * @param members Liste der Mitglieder, welche verwaltet werden soll.
     */
    protected void setMembers(ArrayList<Member> members) {
        this.members = members;
    }

    /**
     * Sortiert alle Mitglieder aus Mitgliederliste nach Nachnamen
     * @param asc Aufsteigend sortieren
     */
    public void sortBySurName(boolean asc) {
        this.getMembers().sort(new Comparator<Member>() {

            @Override
            public int compare(Member o1, Member o2) {
                if (asc) {   // wenn wert true dann wird aufsteigend sortiert 
                    return o1.getSurName().compareTo(o2.getSurName());
                } else {
                    return o2.getSurName().compareTo(o1.getSurName());
                }

            }
        });
    }

    /**
     * Gibt ein einzelnes Mitglied anhand der gegeben Mitgliedsnummer zurueck
     * Wirft Exception, wenn kein Mitglied gefunden wurde.
     * @param memberNumber Mitgliedsnummer
     * @return Mitglied
     * @throws MemberNotFoundException Wenn Mitgliedsnummer nicht gefunden werden konnte.
     */
    public Member getMember(Integer memberNumber) throws MemberNotFoundException {
        for (Member m: getMembers()) {
            if (m.getMemberNumber() == memberNumber) {
                return m;
            }
        }

        throw new MemberNotFoundException();
    }

    /**
     * Sortiert alle Mitglieder aus Mitgliederliste nach Vorname
     * @param asc Aufsteigend sortieren
     */
    public void sortByName(boolean asc) {
        this.getMembers().sort(new Comparator<Member>() {

            @Override
            public int compare(Member o1, Member o2) {
                if (asc) {     // wenn wert true dann wird aufsteigend sortiert
                    return o1.getName().compareTo(o2.getName());
                } else {
                    return o2.getName().compareTo(o1.getName());
                }

            }
        });
    }
   
    /**
     * Sortiert alle Mitglieder aus Mitgliederliste nach Mitgliedsnummer
     * @param asc Aufsteigend sortieren
     */
    public void sortByMemberNumber(boolean asc) {
        this.getMembers().sort(new Comparator<Member>() {

            @Override
            public int compare(Member o1, Member o2) {
                if (asc) {  // wenn wert true dann wird aufsteigend sortiert
                    return o1.getMemberNumber() - o2.getMemberNumber();
                } else {
                    return o2.getMemberNumber() - o1.getMemberNumber();
                }

            }
        });
    }

    /**
     * Sortiert alle Mitglieder aus Mitgliederliste nach Mitgliedstyp
     * @param asc Aufsteigend sortieren
     */
    public void sortByType(boolean asc) {
        this.getMembers().sort(new Comparator<Member>() {

            @Override
            public int compare(Member o1, Member o2) {
                if (asc) {   // wenn wert true dann wird aufsteigend sortiert
                    return o1.getType().compareTo(o2.getType());
                } else {
                    return o2.getType().compareTo(o1.getType());
                }

            }
        });
    }

    /**
     * Ausgeben aller Mitglieder aus Mitgliederliste
     */
    public void print() {

        if (Utils.isNullOrEmpty(getMembers())) {
            System.out.printf("Es existieren keine Mitglieder!%n%n");
        } else {
            for (Member m : getMembers()) {
                System.out.println(m);
            }
        }

    }

}
