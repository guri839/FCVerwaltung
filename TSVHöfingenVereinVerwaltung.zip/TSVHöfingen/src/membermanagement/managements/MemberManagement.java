package membermanagement.managements;

import java.util.ArrayList;

import membermanagement.exceptions.MemberNotFoundException;
import membermanagement.members.Member;
import membermanagement.members.Player;
import membermanagement.members.Trainer;
import utils.exceptions.DuplicateDataException;

/**
 * Diese Klasse verwaltet die Mitgliederliste.
 * Sie kann Mitglieder hinzufuegen und entfernen von der Mitgliederliste.
 */
public class MemberManagement extends BaseManagement {

	/**
	 * Erzeugt ein neues Trainer Objekt und fuegt es der Mitgliederliste hinzu
	 * 
	 * @param memberNumber Mitgliedsnummer
	 * @param name         Name
	 * @param surName      Nachname
	 * @param team         Mannschaft
	 * @throws DuplicateDataException Wenn Mitgliedsnummer schon vergeben ist.
	 */
	public void createTrainer(int memberNumber, String name, String surName, String team)
			throws DuplicateDataException {

		Trainer t = new Trainer(memberNumber, name, surName, team);

		if (this.isMemberExisting(memberNumber)) {
			throw new DuplicateDataException(String.format("%s is already existing!", t));
		}

		// Fuegt den Trainer der Mitgliederliste hinzu
		this.getMembers().add(t);
	}

	/**
	 * Erzeugt ein neues Spieler Objekt und fuegt es der Mitgliederliste hinzu
	 * 
	 * @param memberNumber Mitgleidsnummer
	 * @param name         Vorname
	 * @param surName      Nachname
	 * @param goals        Tore
	 * @param team         Mannschaft
	 * @param position     Position
	 * @throws DuplicateDataException Wenn Mitgliedsnummer schon vergeben ist.
	 */
	public void createPlayer(int memberNumber, String name, String surName, int goals, String team,
			String position) throws DuplicateDataException {

		Player s = new Player(memberNumber, name, surName, goals, team, position);

		if (this.isMemberExisting(memberNumber)) {
			throw new DuplicateDataException(String.format("%s is already existing!", s));
		}

		this.getMembers().add(s);

	}

	/**
	 * Fuegt eine bereits existierende Instanz eines Mitglieds der Mitgliederliste hinzu
	 * @param m Mitglied
	 * @throws DuplicateDataException Wenn Mitgliedsnummer schon vergeben ist.
	 */
	public void add(Member m) throws DuplicateDataException {

		if (this.isMemberExisting(m)) {
			throw new DuplicateDataException(String.format("%s is already existing!", m));
		}

		this.getMembers().add(m);
	}

	/**
	 * Sagt aus ob ein Mitglied bereits in der Mitgliederliste existiert
	 * @param m Mitglied
	 * @return true -> Mitglied existiert. Sonst false. 
	 */
	private boolean isMemberExisting(Member m) {
		return this.isMemberExisting(m.getMemberNumber());
	}

	/**
	 * @see MemberManagement#isMemberExisting(Member)
	 * @param memberNumber Mitgliedsnummer
	 * @return true -> Mitglied existiert. Sonst false. 
	 */
	private boolean isMemberExisting(int memberNumber) {
		try {
			if (this.getMember(memberNumber) != null) {
				return true;
			}
		} catch (Exception e) {
			// pass
		}
		return false;
	}

	/**
	 * @see MemberManagement#deleteMember(Member)
	 * @param memberNumber Mitgliedsnummer
	 * @throws MemberNotFoundException Wenn Mitglied nicht gefunden wurde.
	 */
	public void deleteMember(int memberNumber) throws MemberNotFoundException {
		deleteMember(this.getMember(memberNumber));
	}

	/**
	 * Entfernt gegebenes Mitglied aus der Mitgliederliste, sofern es existiert.
	 * @param m Mitglied
	 * @throws MemberNotFoundException Wenn Mitglied nicht gefunden wurde.
	 */
	public void deleteMember(Member m) throws MemberNotFoundException {
		if (!this.getMembers().remove(m)) {
			throw new MemberNotFoundException();
		}
	}

	/**
	 * Erzeugt eine Instanz einer Spielerverwaltung, welche alle Mitglieder vom Typ Spieler beinhaltet.
	 * @return Spielerverwaltung
	 */
	public PlayerManagement getPlayerManagement() {
		return new PlayerManagement(filterMemberType(Player.TYPE));
	}

	/**
	 * Erzeugt eine Instanz einer Trainerverwaltung, welche alle Mitglieder vom Typ Trainer beinhaltet.
	 * @return Spielerverwaltung
	 */
	public TrainerManagement getTrainerManagement() {
		return new TrainerManagement(filterMemberType(Trainer.TYPE));
	}

	/**
	 * Filtert Mitgliederliste anhand von Mitgliedstyp.
	 * Erzeugt eine separate gefilterte Liste und gibt diese zurueck.
	 * @param filterType Mitgliedstyp nach welche gefiltert werden soll.
	 * @return Liste gefilterter Mitglieder
	 */
	private ArrayList<Member> filterMemberType(String filterType) {
		ArrayList<Member> filtered = new ArrayList<>();

		for (Member m : getMembers()) {
			if (m.getType() == filterType) {
				filtered.add(m);
			}
		}

		return filtered;
	}

}
