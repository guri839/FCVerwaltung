package membermanagement.managements;

import java.util.ArrayList;
import java.util.Comparator;

import membermanagement.members.Member;
import membermanagement.members.Player;

/**
 * Mitgliederverwaltungsklasse, welche nur Mitglieder des Typs Spieler beinhaltet.
 * Diese Klasse bietet nur Lesende Aktionen auf die Mitglieder liste.
 * Sie dient als gefilterte Version der Hauptverwaltung (Mitgliederverwaltung).
 * Wird verwedent um z.B: nur alle Spieler auf zu listen.
 * 
 * Sortierfunktionen f�r Eigenschaften, welche nur Spieler besitzen, sollen
 * hier ebenfalls implementiert werden.
 */
public class PlayerManagement extends BaseManagement {

    /**
     * Diese Klasse wird von {@link MemberManagement#getPlayerManagement()} ausgestellt und sollte
     * auch nur von dieser  instaziert werden.
     * @param players Mitgliederliste welche nur Spieler beinhaltet
     */
    PlayerManagement(ArrayList<Member> players) {
        super();
        this.setMembers(players);
    }

    /**
     * Soll ueber diesen Weg nicht instanziert werden!
     */
    PlayerManagement() {
        throw new InstantiationError(String.format("%s", getClass()));
    }

    /**
     * Sortiert alle Spieler aus Mitgliederliste nach Team
     * @param asc Aufsteigend sortieren
     */
    public void sortByTeams(boolean asc) {
        this.getMembers().sort(new Comparator<Member>() {

            @Override
            public int compare(Member o1, Member o2) {
                Player t1 = (Player) o1;
                Player t2 = (Player) o2;

                if (asc) {       // Falls Wert wahr aufsteigend sort.
                    return t1.getTeam().compareTo(t2.getTeam());
                } else {
                    return t2.getTeam().compareTo(t1.getTeam());
                }

            }
        });
    }

   /**
     * Sortiert alle Spieler aus Mitgliederliste nach Toren
     * @param asc Aufsteigend sortieren
     */
    public void sortByGoals(boolean asc) {
        this.getMembers().sort(new Comparator<Member>() {

            @Override
            public int compare(Member o1, Member o2) {
                Player t1 = (Player) o1;
                Player t2 = (Player) o2;

                if (asc) {    // Falls Wert wahr aufsteigend sort.
                    return t1.getGoals() - t2.getGoals();
                } else {
                    return t2.getGoals() - t1.getGoals();
                }

            }
        });
    }

   /**
     * Sortiert alle Spieler aus Mitgliederliste nach Position
     * @param asc Aufsteigend sortieren
     */
    public void sortByPosition(boolean asc) {
        this.getMembers().sort(new Comparator<Member>() {

            @Override
            public int compare(Member o1, Member o2) {
                Player t1 = (Player) o1;
                Player t2 = (Player) o2;

                if (asc) {     // Falls Wert wahr aufsteigend sort.
                    return t1.getPosition().compareTo(t2.getPosition());
                } else {
                    return t2.getPosition().compareTo(t1.getPosition());
                }
            }
        });
    }

}
