package membermanagement.exceptions;

/**
 * Wird geworfen wenn ein Mitglied nicht gefunden werden kann.
 */
public class MemberNotFoundException extends Exception {
    
}
