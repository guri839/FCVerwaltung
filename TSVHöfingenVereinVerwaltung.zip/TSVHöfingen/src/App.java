import cli.CLI;
import membermanagement.managements.MemberManagement;

/**
 * Einstiegsklasse der Anwendung.
 */
public class App {

	/**
	 * Mainmethode
	 * @param args String[]
	 */
	public static void main(String[] args) {
		// Erzeuge mitglieder verwaltung
		MemberManagement mm = new MemberManagement();

		// CLI mitglieder verwaltungs instanz uebergeben
		CLI.memberManagement = mm;
		
		// Starte Hauptmenue
		CLI.mainMenu();
	}
}
